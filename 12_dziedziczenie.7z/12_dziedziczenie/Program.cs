﻿using _12_dziedziczenie.classes;

namespace _12_dziedziczenie
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Janusz", "Nowak", 190.5f, 70f);
            Console.WriteLine(person.Info());

            Employee employee = new Employee("Anna", "Nowak", 165.5f, 60f, "ZSK", 33.5f, 200);
            Console.WriteLine(employee.Info());
        }
    }
}