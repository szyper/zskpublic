﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_dziedziczenie.classes
{
    internal class Employee : Person
    {
        private string workplace = "";
        private float ratePerHour = 0f;
        private ushort numberOfWorkHours = 0;

        public Employee() { }
        public Employee(string imie, string lastName, float height, float weight, string workplace, float ratePerHour, ushort numberOfWorkHours) : base(imie, lastName, height, weight)
        {
            this.workplace = workplace;
            this.ratePerHour = ratePerHour;
            this.numberOfWorkHours = numberOfWorkHours;
        }

        private float Salary()
        {
            return ratePerHour * numberOfWorkHours;
        }

        public new string Info()
        {
            return base.Info() + ", miejsce pracy: " + workplace + ", pensja: " + Salary().ToString("c2");
        }
    }
}
