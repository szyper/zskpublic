﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_dziedziczenie.classes
{
    internal class Person
    {
        public string firstName = "";
        public string lastName = "";
        private float height = 0f;
        private float weight = 0f;

        public Person() { }

        public Person(string firstName, string lastName, float height, float weight)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.height = height;
            this.weight = weight;
        }

        public string Info()
        {
            return "Imię i nazwisko: " + firstName + " " + lastName + ", wzrost: " + height.ToString("0.00").Replace(',','.') + "cm, waga: " + weight.ToString("0.00").Replace(',', '.') + "kg";
        }
    }
}
