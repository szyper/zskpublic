﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] tabInt = { 1, 2, 3, -4, 5, 6, 7, 80, 9, 10 };
            Console.WriteLine("Ilość elementow: " + tabInt.Length);

            for (int i = 0; i < tabInt.Length; i++) 
            {
                Console.Write($"{tabInt[i]}  ");
            }
            Console.WriteLine();

            foreach (int x in tabInt)
            {
                Console.Write($"{x} ");
            }
            Console.WriteLine();

            for (int i = 0; i < tabInt.Length; i++)
            {
                tabInt[i] *= 2;
                Console.Write($"{tabInt[i]}  ");
            }
            Console.WriteLine();

            foreach (int x in tabInt)
            {
                //x *= 2; //read-only
                Console.Write($"{x} ");
            }
            Console.WriteLine();

            //2 4 6 -8 10 12 14 160 18 20
            Console.WriteLine(tabInt.Min()); //-8
            Console.WriteLine(tabInt.Max()); //160
            Console.WriteLine();

            Array.Reverse(tabInt);
            foreach (int x in tabInt)
            {
                //x *= 2; //read-only
                Console.Write($"{x} ");
            }
            Console.WriteLine();
            //20 18 160 14 12 10 -8 6 4 2

            Array.Reverse(tabInt, 2, 3);
            foreach (int x in tabInt)
            {
                Console.Write($"{x} ");
            }
            Console.WriteLine();
            //20 18 12 14 160 10 -8 6 4 2

            Console.WriteLine(Array.BinarySearch(tabInt, 2)); //-1
            Array.Sort(tabInt);
            Console.WriteLine(Array.BinarySearch(tabInt, 2)); //1
            Console.WriteLine(Array.BinarySearch(tabInt, 22)); //-10

            //zad
            Console.Write("\n\nPodaj ilość elementów w tablicy:");
            int N = int.Parse(Console.ReadLine());
            int[] tab = new int[N];
            for (int i = 0;i < tab.Length;i++)
            {
                tab[i] = i + 1;
                Console.Write($"{tab[i]} ");
            }
        }
    }
}