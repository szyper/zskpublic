﻿namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            City c = new City("Poznań", "61-600", "Polska", 19516750, 18233250, 37750000);

            //dokończyć definicję klasy CsvReader
        }
    }
}