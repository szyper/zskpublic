﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class City
    {
        public string cityName = "";
        public string cityCode = "";
        public string country = "";
        public int womenPopulation = 0;
        public int menPopulation = 0;
        public int totalPopulation = 0;

        public City(string _cityName, string _cityCode, string _country, int _womenPopulation, int _menPopulation, int _totalPopulation)
        {
            cityName = _cityName;
            cityCode = _cityCode;
            country = _country;
            womenPopulation = _womenPopulation;
            menPopulation = _menPopulation;
            totalPopulation = _totalPopulation;
        }
    }
}
