﻿using _8_dziedziczenie_1.classes;

namespace Program
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person();
            Console.WriteLine(p1.Info());

            Person p2 = new Person("Janusz", "Kowal", 180.5f, 85);
            Console.WriteLine(p2.Info());

            Employee e = new Employee();
            Console.WriteLine(e.Info());

            Employee e1 = new Employee("Janusz", "Pracownik", 200.5f, 100.1f, "ZSK", 50.5f, 100);
            Console.WriteLine(e1.Info());

            Driver d1 = new Driver();
            Console.WriteLine(d1.Info());

            Driver d2 = new Driver("Anna", "Kierowca", 200.5f, 100.1f, "ZSK", 50.5f, 100, Driver.drivingLicenseCategories.b);
            Console.WriteLine(d2.Info());

            d2.drivingLicenseCategory.Add(Driver.drivingLicenseCategories.c);
            Console.WriteLine(d2.Info());

        }
    }
}