﻿using Program;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _8_dziedziczenie_1.classes
{
    internal class Driver : Employee
    {
        public enum drivingLicenseCategories { a, b, c, d };

        public List<drivingLicenseCategories> drivingLicenseCategory = new List<drivingLicenseCategories>();

        public Driver() { }

        public Driver(string firstName, string lastName, float height, float weight, string workplace, float ratePerWorkHour, ushort numberOfWorkHours, drivingLicenseCategories drivingLicenseCategory) : base(firstName, lastName, height, weight, workplace, ratePerWorkHour, numberOfWorkHours)
        {
            this.drivingLicenseCategory.Add(drivingLicenseCategory);
        }

        public string showDrivingLicenses()
        {
            string licenses = "";
            foreach (drivingLicenseCategories license in drivingLicenseCategory)
            {
                licenses += license + " ";
            }
            return licenses;
        }

        public new string Info()
        {
            return base.Info() + ", kategoria/e prawa jazdy: " + showDrivingLicenses();
        }
    }
}
