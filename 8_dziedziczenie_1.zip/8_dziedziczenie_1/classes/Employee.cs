﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class Employee : Person
    {
        private string workplace = "";
        private float ratePerWorkHour = 0f;
        private ushort numberOfWorkHours = 0; //tablica miesięcy

        private float salary()
        {
            return ratePerWorkHour * numberOfWorkHours;
        }

        public Employee() { }

        public Employee(string firstName, string lastName, float height, float weight, string workplace, float ratePerWorkHour, ushort numberOfWorkHours) : base(firstName, lastName, height, weight)
        {
            this.workplace = workplace;
            this.ratePerWorkHour = ratePerWorkHour;
            this.numberOfWorkHours = numberOfWorkHours;
        }

        public new string Info()
        {
            return base.Info() + ", pensja: " + salary().ToString("C2");
        }
    }
}
