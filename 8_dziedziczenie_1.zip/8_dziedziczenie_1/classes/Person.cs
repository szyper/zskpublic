﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    internal class Person
    {
        public string firstName = "";
        public string lastName = "";
        public float height = 0f;
        public float weight = 0f;

        public Person() { }

        public Person(string firstName, string lastName, float height, float weight)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.height = height;
            this.weight = weight;
        }

        public string Info()
        {
            return "Imię i nazwisko: " + firstName + " " + lastName + ",waga: " + weight + "kg, wzrost: " + height + "cm";
        }
    }
}
