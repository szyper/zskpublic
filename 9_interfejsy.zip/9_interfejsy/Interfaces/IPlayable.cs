﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_interfejsy.Interfaces
{
    internal interface IPlayable
    {
        void Stop();
        void Pause();
        void Play();
    }
}
