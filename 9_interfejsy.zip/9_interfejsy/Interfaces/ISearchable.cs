namespace _9_interfejsy.Interfaces;

public interface ISearchable
{
    void Rev()
    {
        Console.WriteLine("Interfejs ISearchable - metoda Rev");
    }

    void FastRev();
    void Fwd();
    void FastFwd();
}