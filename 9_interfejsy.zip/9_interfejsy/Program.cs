﻿using _9_interfejsy.classes;
using _9_interfejsy.Interfaces;

namespace _9_interfejsy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Media media = new Media();
            //media.Stop();

            Film film = new Film();
            //film.Stop();

            IPlayable[] tabMedia = new IPlayable[4];

            tabMedia[0] = new Film();
            tabMedia[0].Play();

            tabMedia[1] = new Film();
            tabMedia[1].Play();

            tabMedia[2] = new Music();
            tabMedia[2].Play();
            Console.WriteLine();

            tabMedia[3] = new Comedy();

            for (int i = 0; i < tabMedia.Length; i++)
            {
                tabMedia[i].Pause();
            }
            Console.WriteLine();

            foreach (IPlayable item in tabMedia)
            {
                item.Pause();
            }

        }
    }
}