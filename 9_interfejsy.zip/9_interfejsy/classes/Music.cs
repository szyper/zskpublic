﻿using _9_interfejsy.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_interfejsy.classes
{
    internal class Music : IPlayable
    {
        public void Stop()
        {
            Console.WriteLine("Klasa Music - metoda STOP");
        }

        public void Pause()
        {
            Console.WriteLine("Klasa Music - metoda PAUSE");
        }

        public void Play()
        {
            Console.WriteLine("Klasa Music - metoda PLAY");
        }
    }
}
